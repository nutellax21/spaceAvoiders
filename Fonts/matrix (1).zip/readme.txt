Siesta Fonts -- http://rubberducky.nu/siesta

All my fonts are unrestricted freeware for personal use. They are not allowed to be used in any sort of commercial package - if anyone's going to make money out of my creations it'll be me, thank you very much.

If you do use any of my fonts, it would be great if you could let me know - just out of courtesy - I like to know my fonts are being used. The fonts may be distributed freely as freeware, as long as they retain their readme text files. If you wish to include one or more fonts in an online archive, again let me know - and if possible a link would be great.

You may not rename or rework/edit any of my fonts without my permission, or distribute them without the relevant readme file.

-Charlotte
siesta@rubberducky.nu